package com.example.listcitywed;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView cityList;
    ArrayAdapter<String> cityAdapter;
    ArrayList<String> dataList;
    Button add;
    Button delete;
    Button confirm;
    EditText cityInput;
    int pos = ListView.INVALID_POSITION;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cityList = findViewById(R.id.city_list);
        add = findViewById(R.id.button7);
        delete = findViewById(R.id.button9);

        confirm = findViewById(R.id.button10);
        confirm.setVisibility(View.INVISIBLE);

        cityInput = findViewById(R.id.editTextText);
        cityInput.setVisibility(View.INVISIBLE);

        String []cities = {"Edmonton", "Vancouver", "Tokyo", "Osaka", "Berlin", "Sydney", "Beijing"};
        dataList = new ArrayList<>();
        dataList.addAll(Arrays.asList(cities));

        cityAdapter = new ArrayAdapter<>(this, R.layout.content, dataList);
        cityList.setAdapter(cityAdapter);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirm.setVisibility(View.VISIBLE);
                cityInput.setVisibility(View.VISIBLE);
            }
        });

        confirm.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCity();
            }
        }));

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delCity();
            }
        });

        cityList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pos = position;
                cityAdapter.notifyDataSetChanged();
            }
        });
    }

    private void addCity(){
        String city = cityInput.getText().toString();
        if (!city.isEmpty()){
            dataList.add(city);
            cityAdapter.notifyDataSetChanged();
            cityInput.getText().clear();
        }
    }

    private void delCity(){
        if (pos != ListView.INVALID_POSITION) {
            View selectedView = cityList.getChildAt(pos);
            dataList.remove(pos);
            pos = ListView.INVALID_POSITION;
            cityAdapter.notifyDataSetChanged();
        }
    }
}